Version Info:

This is Thrash'It Vesion 0.1.a (for details please visit www.geocitites.com/thrashit3d)

1. Executable
You need to have DirectX7 or higher installed

the program will start with a blank screen, 
if it causes any damage (i strongly doubt it will excecpt maybe psychological) dont sue me cause i dont have any money.

F9 turn rendering on/off (defauls is OFF)
F2-F3-F4 select rendering mode
F5 log performance to ThrashIt3D.log

2. Source Code

The source code provided will not compile since it relies on other FiveMagics* libraries.
But all 3D algorithms and data structures are there so u could probably use it with some tweaking.
Feel free to use it any way you would like just let me know.

3. Contact
FiveMagics@fivemagics.org
jadnohra@hotmail.com

www.geocitites.com/thrashit3d
www.fivemagics.org


